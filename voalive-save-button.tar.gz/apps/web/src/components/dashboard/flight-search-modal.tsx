'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Dialog, DialogContent, DialogHeader, DialogTitle, Button, Input, Label } from '@reservasegura/ui';
import { Search, Plane, Loader2, Save } from 'lucide-react';

interface FlightData {
  numeroVoo: string;
  origem: string;
  destino: string;
  horarioPartida: string;
  horarioChegada: string;
  horarioPartidaReal?: string;
  horarioChegadaReal?: string;
  horarioPartidaEstimado?: string;
  horarioChegadaEstimado?: string;
  dataPartida?: string;
  status: string;
  companhia?: string;
  portao?: string;
  portaoChegada?: string;
  terminal?: string;
  terminalChegada?: string;
  posicao?: {
    latitude: number;
    longitude: number;
    altitude?: number;
    velocidade?: number;
    direcao?: number;
    velocidadeVertical?: number;
  };
  atrasado?: number;
  duracao?: number;
  aeronave?: string;
  registro?: string;
  ultimaAtualizacao?: string;
}

interface FlightSearchModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onFlightFound: (flight: FlightData) => void;
}

export function FlightSearchModal({ open, onOpenChange, onFlightFound }: FlightSearchModalProps) {
  const router = useRouter();
  const [flightNumber, setFlightNumber] = useState('');
  const [localizador, setLocalizador] = useState('');
  const [ultimoNome, setUltimoNome] = useState('');
  const [origem, setOrigem] = useState('');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [flightInfo, setFlightInfo] = useState<FlightData | null>(null);

  const isGol = (flightNum: string): boolean => {
    const code = flightNum.substring(0, 2).toUpperCase();
    return code === 'G3';
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!flightNumber.trim() || flightNumber.length < 4) {
      setError('Por favor, digite um número de vôo válido (mínimo 4 caracteres)');
      return;
    }

    // Validação específica para GOL
    if (isGol(flightNumber)) {
      if (!localizador.trim()) {
        setError('Para voos GOL, o Localizador é obrigatório');
        return;
      }
      if (!ultimoNome.trim()) {
        setError('Para voos GOL, o Último Nome é obrigatório');
        return;
      }
      if (!origem.trim()) {
        setError('Para voos GOL, a Origem é obrigatória');
        return;
      }
    }

    setLoading(true);
    setError('');
    setFlightInfo(null);

    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

      // LÓGICA HÍBRIDA:
      // Se tiver localizador + sobrenome → usa endpoint de scraping (Playwright)
      // Se tiver apenas número de vôo → usa endpoint de APIs externas
      const hasBookingInfo = localizador.trim() && ultimoNome.trim();

      if (hasBookingInfo) {
        // Busca usando LOCALIZADOR + SOBRENOME (Scraping com Playwright)
        console.log('🔍 Buscando reserva com localizador:', localizador);

        const response = await fetch(`${apiUrl}/api/v1/airline-booking/search-booking`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            localizador: localizador.trim().toUpperCase(),
            sobrenome: ultimoNome.trim().toUpperCase(),
            origem: origem.trim().toUpperCase() || undefined,
          }),
        });

        const result = await response.json();

        if (result.success && result.data) {
          console.log('✅ Reserva encontrada:', result.data);

          // Mapear dados da reserva para formato esperado pelo modal
          const flightData = {
            numeroVoo: result.data.numeroVoo || flightNumber.trim().toUpperCase(),
            origem: result.data.origem || '',
            destino: result.data.destino || '',
            horarioPartida: result.data.horarioPartida || '',
            horarioChegada: result.data.horarioChegada || '',
            dataPartida: result.data.dataPartida || new Date().toISOString().split('T')[0],
            status: result.data.status || 'CONFIRMED',
            companhia: result.data.companhia || getAirlineFromCode(flightNumber),
            portao: result.data.portao,
            terminal: result.data.terminal,
            aeronave: result.data.aeronave,
          };

          setFlightInfo(flightData);
          // NÃO chamar onFlightFound nem fechar o modal automaticamente
          // Esperar o usuário clicar em "Salvar"
        } else {
          setError(result.message || result.error || 'Reserva não encontrada. Verifique os dados e tente novamente.');
          console.warn('⚠️ Reserva não encontrada:', result);
        }
      } else {
        // Busca usando NÚMERO DE VÔO (APIs externas: AirLabs, etc)
        console.log('🔍 Buscando vôo por número:', flightNumber);

        const response = await fetch(`${apiUrl}/api/v1/flight-search/search`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            flightNumber: flightNumber.trim().toUpperCase()
          }),
        });

        const result = await response.json();

        if (result.success && result.data) {
          console.log('✅ Vôo encontrado:', result.data);
          setFlightInfo(result.data);
          // NÃO chamar onFlightFound nem fechar o modal automaticamente
          // Esperar o usuário clicar em "Salvar"
        } else {
          setError(result.error || 'Vôo não encontrado. Verifique o número e tente novamente.');
          console.warn('⚠️ Vôo não encontrado:', result);
        }
      }
    } catch (error: any) {
      console.error('❌ Erro na busca:', error);
      setError(`Erro ao buscar vôo: ${error.message || 'Verifique sua conexão'}`);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Salva a reserva para monitoramento e redireciona para /bookings
   */
  const handleSave = async () => {
    if (!flightInfo) return;

    setSaving(true);
    setError('');

    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

      console.log('💾 Salvando reserva para monitoramento...');

      const response = await fetch(`${apiUrl}/api/monitoring/bookings`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          pnr: localizador.toUpperCase() || `AUTO-${flightInfo.numeroVoo}-${Date.now()}`,
          airline: flightInfo.companhia || getAirlineFromCode(flightInfo.numeroVoo),
          lastName: ultimoNome.toUpperCase() || 'AUTO',
          flightNumber: flightInfo.numeroVoo,
          departureDate: flightInfo.dataPartida ? new Date(flightInfo.dataPartida) : new Date(),
          route: `${flightInfo.origem}-${flightInfo.destino}`,
          checkInterval: 5, // Verificar a cada 5 minutos
        }),
      });

      const result = await response.json();

      if (result.success) {
        console.log('✅ Reserva salva com sucesso!');

        // Chamar callback com os dados do voo
        onFlightFound(flightInfo);

        // Fechar modal
        onOpenChange(false);

        // Limpar campos
        setFlightNumber('');
        setLocalizador('');
        setUltimoNome('');
        setOrigem('');
        setFlightInfo(null);
        setError('');

        // Redirecionar para página de reservas
        router.push('/bookings');
      } else {
        setError(result.message || 'Erro ao salvar reserva para monitoramento');
        console.error('❌ Erro ao salvar reserva:', result);
      }
    } catch (error: any) {
      console.error('❌ Erro ao salvar reserva:', error);
      setError(`Erro ao salvar: ${error.message || 'Tente novamente'}`);
    } finally {
      setSaving(false);
    }
  };

  const formatFlightNumber = (value: string) => {
    // Remove espaços e converte para maiúsculas
    return value.toUpperCase().replace(/\s/g, '');
  };

  const handleFlightNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatFlightNumber(e.target.value);
    setFlightNumber(formatted);
    setError('');
  };

  const getAirlineFromCode = (flightNum: string): string => {
    const code = flightNum.substring(0, 2).toUpperCase();
    const airlineMap: { [key: string]: string } = {
      'LA': 'LATAM',
      'JJ': 'LATAM',
      'G3': 'GOL',
      'AD': 'AZUL',
      'AV': 'AVIANCA',
      'TP': 'TAP',
      'AF': 'Air France',
      'KL': 'KLM',
      'BA': 'British Airways',
      'AA': 'American Airlines',
      'UA': 'United Airlines',
      'DL': 'Delta',
    };
    return airlineMap[code] || 'Companhia';
  };

  const getAirlineFlag = (flightNum: string): string => {
    const code = flightNum.substring(0, 2).toUpperCase();
    const flagMap: { [key: string]: string } = {
      'LA': '🇧🇷',
      'JJ': '🇧🇷',
      'G3': '🇧🇷',
      'AD': '🇧🇷',
      'AV': '🇨🇴',
      'TP': '🇵🇹',
      'AF': '🇫🇷',
      'KL': '🇳🇱',
      'BA': '🇬🇧',
      'AA': '🇺🇸',
      'UA': '🇺🇸',
      'DL': '🇺🇸',
    };
    return flagMap[code] || '✈️';
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Plane className="h-5 w-5 text-blue-600" />
            Buscar Reserva
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSearch} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="flightNumber">
              Número do Vôo <span className="text-red-600">*</span>
            </Label>
            <div className="relative">
              <Input
                id="flightNumber"
                value={flightNumber}
                onChange={handleFlightNumberChange}
                placeholder="Ex: LA3789, G31234"
                required
                minLength={4}
                maxLength={8}
                className="pr-10 font-mono text-lg"
                disabled={loading}
                autoFocus
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2">
                {loading ? (
                  <Loader2 className="h-4 w-4 animate-spin text-blue-600" />
                ) : (
                  <Search className="h-4 w-4 text-gray-400" />
                )}
              </div>
            </div>
          </div>

          {/* Campos adicionais - obrigatórios para GOL, recomendados para LATAM */}
          <div className="grid grid-cols-1 gap-3">
            <div className="space-y-2">
              <Label htmlFor="localizador">
                Localizador {isGol(flightNumber) && <span className="text-red-600">*</span>}
                {!isGol(flightNumber) && flightNumber.trim() && <span className="text-gray-500 text-xs ml-1">(recomendado)</span>}
              </Label>
              <Input
                id="localizador"
                value={localizador}
                onChange={(e) => {
                  setLocalizador(e.target.value.toUpperCase());
                  setError('');
                }}
                placeholder="Ex: 0JOCXW, ABC123"
                maxLength={8}
                className="font-mono"
                disabled={loading}
                required={isGol(flightNumber)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="ultimoNome">
                Último Nome {isGol(flightNumber) && <span className="text-red-600">*</span>}
                {!isGol(flightNumber) && flightNumber.trim() && <span className="text-gray-500 text-xs ml-1">(recomendado)</span>}
              </Label>
              <Input
                id="ultimoNome"
                value={ultimoNome}
                onChange={(e) => {
                  setUltimoNome(e.target.value.toUpperCase());
                  setError('');
                }}
                placeholder="Ex: JUNIOR, SILVA"
                className="font-mono"
                disabled={loading}
                required={isGol(flightNumber)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="origem">
                Origem (IATA) {isGol(flightNumber) && <span className="text-red-600">*</span>}
                {!isGol(flightNumber) && flightNumber.trim() && <span className="text-gray-500 text-xs ml-1">(recomendado)</span>}
              </Label>
              <Input
                id="origem"
                value={origem}
                onChange={(e) => {
                  setOrigem(e.target.value.toUpperCase());
                  setError('');
                }}
                placeholder="Ex: POA, GRU, CGH"
                maxLength={3}
                minLength={3}
                className="font-mono"
                disabled={loading}
                required={isGol(flightNumber)}
              />
            </div>
          </div>

          {/* Alerta para voos GOL */}
          {isGol(flightNumber) && (
            <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-md">
              <p className="text-sm text-yellow-800">
                <strong>Voos GOL:</strong> É necessário informar o Localizador, Último Nome e Origem para realizar a busca.
              </p>
            </div>
          )}

          {/* Alerta para LATAM/outras companhias */}
          {!isGol(flightNumber) && flightNumber.trim() && flightNumber.length >= 4 && (
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-md">
              <p className="text-sm text-blue-800">
                <strong>💡 Dica:</strong> Para obter dados mais precisos da sua reserva LATAM, preencha também o Localizador e Último Nome. Isso permitirá buscar informações diretamente do site da companhia aérea.
              </p>
            </div>
          )}

          {/* Success State */}
          {flightInfo && !error && (
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg space-y-3 max-h-96 overflow-y-auto">
              <div className="flex items-center gap-2 text-green-700 font-medium">
                <span className="text-xl">✅</span>
                <span>Vôo Encontrado!</span>
              </div>

              {/* Informações Básicas */}
              <div className="text-sm space-y-1.5 border-b border-green-200 pb-3">
                <div className="flex justify-between">
                  <span className="text-green-700 font-medium">Vôo:</span>
                  <span className="font-mono font-bold text-green-900">{flightInfo.numeroVoo}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-green-700 font-medium">Companhia:</span>
                  <span className="font-medium text-green-900">{flightInfo.companhia || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-green-700 font-medium">Rota:</span>
                  <span className="font-medium text-green-900">{flightInfo.origem} → {flightInfo.destino}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-green-700 font-medium">Status:</span>
                  <span className={`font-semibold px-2 py-0.5 rounded text-xs ${
                    flightInfo.status?.includes('EM VOO') ? 'bg-blue-100 text-blue-800' :
                    flightInfo.status?.includes('ATRASADO') || flightInfo.atrasado ? 'bg-yellow-100 text-yellow-800' :
                    flightInfo.status?.includes('CANCELADO') ? 'bg-red-100 text-red-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {flightInfo.status}
                  </span>
                </div>
              </div>

              {/* Horários */}
              <div className="text-sm space-y-1.5 border-b border-green-200 pb-3">
                <div className="font-medium text-green-700 mb-1">⏰ Horários:</div>
                <div className="flex justify-between">
                  <span className="text-green-700">Partida Programada:</span>
                  <span className="font-medium text-green-900">{flightInfo.horarioPartida || 'N/A'}</span>
                </div>
                {flightInfo.horarioPartidaReal && (
                  <div className="flex justify-between">
                    <span className="text-green-700">Partida Real:</span>
                    <span className="font-medium text-blue-900">{flightInfo.horarioPartidaReal}</span>
                  </div>
                )}
                {flightInfo.horarioPartidaEstimado && !flightInfo.horarioPartidaReal && (
                  <div className="flex justify-between">
                    <span className="text-green-700">Partida Estimada:</span>
                    <span className="font-medium text-orange-900">{flightInfo.horarioPartidaEstimado}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-green-700">Chegada Programada:</span>
                  <span className="font-medium text-green-900">{flightInfo.horarioChegada || 'N/A'}</span>
                </div>
                {flightInfo.horarioChegadaReal && (
                  <div className="flex justify-between">
                    <span className="text-green-700">Chegada Real:</span>
                    <span className="font-medium text-blue-900">{flightInfo.horarioChegadaReal}</span>
                  </div>
                )}
                {flightInfo.horarioChegadaEstimado && !flightInfo.horarioChegadaReal && (
                  <div className="flex justify-between">
                    <span className="text-green-700">Chegada Estimada:</span>
                    <span className="font-medium text-orange-900">{flightInfo.horarioChegadaEstimado}</span>
                  </div>
                )}
              </div>

              {/* Portões e Terminais */}
              {(flightInfo.portao || flightInfo.terminal || flightInfo.portaoChegada || flightInfo.terminalChegada) && (
                <div className="text-sm space-y-1.5 border-b border-green-200 pb-3">
                  <div className="font-medium text-green-700 mb-1">🚪 Portões e Terminais:</div>
                  {flightInfo.terminal && (
                    <div className="flex justify-between">
                      <span className="text-green-700">Terminal Partida:</span>
                      <span className="font-medium text-green-900">{flightInfo.terminal}</span>
                    </div>
                  )}
                  {flightInfo.portao && (
                    <div className="flex justify-between">
                      <span className="text-green-700">Portão Partida:</span>
                      <span className="font-medium text-green-900">{flightInfo.portao}</span>
                    </div>
                  )}
                  {flightInfo.terminalChegada && (
                    <div className="flex justify-between">
                      <span className="text-green-700">Terminal Chegada:</span>
                      <span className="font-medium text-green-900">{flightInfo.terminalChegada}</span>
                    </div>
                  )}
                  {flightInfo.portaoChegada && (
                    <div className="flex justify-between">
                      <span className="text-green-700">Portão Chegada:</span>
                      <span className="font-medium text-green-900">{flightInfo.portaoChegada}</span>
                    </div>
                  )}
                </div>
              )}

              {/* Posição GPS (se em voo) */}
              {flightInfo.posicao && (
                <div className="text-sm space-y-1.5 border-b border-green-200 pb-3">
                  <div className="font-medium text-green-700 mb-1">📍 Posição em Tempo Real:</div>
                  <div className="flex justify-between">
                    <span className="text-green-700">Latitude:</span>
                    <span className="font-mono text-xs text-green-900">{flightInfo.posicao.latitude.toFixed(4)}°</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-green-700">Longitude:</span>
                    <span className="font-mono text-xs text-green-900">{flightInfo.posicao.longitude.toFixed(4)}°</span>
                  </div>
                  {flightInfo.posicao.altitude && (
                    <div className="flex justify-between">
                      <span className="text-green-700">Altitude:</span>
                      <span className="font-medium text-green-900">{flightInfo.posicao.altitude.toLocaleString()} ft</span>
                    </div>
                  )}
                  {flightInfo.posicao.velocidade && (
                    <div className="flex justify-between">
                      <span className="text-green-700">Velocidade:</span>
                      <span className="font-medium text-green-900">{flightInfo.posicao.velocidade} km/h</span>
                    </div>
                  )}
                  {flightInfo.posicao.direcao && (
                    <div className="flex justify-between">
                      <span className="text-green-700">Direção:</span>
                      <span className="font-medium text-green-900">{flightInfo.posicao.direcao}°</span>
                    </div>
                  )}
                </div>
              )}

              {/* Atrasos */}
              {flightInfo.atrasado !== undefined && flightInfo.atrasado > 0 && (
                <div className="text-sm space-y-1.5 border-b border-green-200 pb-3">
                  <div className="font-medium text-yellow-700 mb-1">⚠️ Atraso:</div>
                  <div className="flex justify-between">
                    <span className="text-yellow-700">Tempo de Atraso:</span>
                    <span className="font-bold text-yellow-900">{flightInfo.atrasado} minutos</span>
                  </div>
                </div>
              )}

              {/* Aeronave */}
              {(flightInfo.aeronave || flightInfo.registro) && (
                <div className="text-sm space-y-1.5">
                  <div className="font-medium text-green-700 mb-1">✈️ Aeronave:</div>
                  {flightInfo.aeronave && (
                    <div className="flex justify-between">
                      <span className="text-green-700">Tipo:</span>
                      <span className="font-medium text-green-900">{flightInfo.aeronave}</span>
                    </div>
                  )}
                  {flightInfo.registro && (
                    <div className="flex justify-between">
                      <span className="text-green-700">Registro:</span>
                      <span className="font-mono text-xs text-green-900">{flightInfo.registro}</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Error State */}
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-md">
              <p className="text-sm text-red-600">
                {error}
              </p>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                onOpenChange(false);
                setFlightNumber('');
                setLocalizador('');
                setUltimoNome('');
                setOrigem('');
                setError('');
                setFlightInfo(null);
              }}
              disabled={loading || saving}
            >
              Cancelar
            </Button>

            {/* Mostrar "Buscar" quando não houver resultados, "Salvar" quando houver */}
            {!flightInfo ? (
              <Button
                type="submit"
                disabled={flightNumber.length < 4 || loading}
                className="min-w-24"
              >
                {loading ? (
                  <div className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Buscando...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Search className="h-4 w-4" />
                    Buscar
                  </div>
                )}
              </Button>
            ) : (
              <Button
                type="button"
                onClick={handleSave}
                disabled={saving}
                className="min-w-24 bg-green-600 hover:bg-green-700"
              >
                {saving ? (
                  <div className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Salvando...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Save className="h-4 w-4" />
                    Salvar
                  </div>
                )}
              </Button>
            )}
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
