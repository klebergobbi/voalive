(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[663],{4040:function(e,t,r){Promise.resolve().then(r.bind(r,5396)),Promise.resolve().then(r.bind(r,5039))},1236:function(e,t,r){"use strict";r.d(t,{Z:function(){return s}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(8525).Z)("BarChart",[["line",{x1:"12",x2:"12",y1:"20",y2:"10",key:"1vz5eb"}],["line",{x1:"18",x2:"18",y1:"20",y2:"4",key:"cun8e5"}],["line",{x1:"6",x2:"6",y1:"20",y2:"16",key:"hq0ia6"}]])},3385:function(e,t,r){"use strict";r.d(t,{Z:function(){return s}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(8525).Z)("Calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]])},4565:function(e,t,r){"use strict";r.d(t,{Z:function(){return s}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(8525).Z)("CreditCard",[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}]])},5104:function(e,t,r){"use strict";r.d(t,{Z:function(){return s}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(8525).Z)("HelpCircle",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3",key:"1u773s"}],["path",{d:"M12 17h.01",key:"p32p05"}]])},7526:function(e,t,r){"use strict";r.d(t,{Z:function(){return s}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(8525).Z)("Plane",[["path",{d:"M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z",key:"1v9wt8"}]])},8487:function(e,t,r){"use strict";r.d(t,{Z:function(){return s}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(8525).Z)("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]])},7542:function(e,t,r){"use strict";r.d(t,{Z:function(){return s}});/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(8525).Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},5396:function(e,t,r){"use strict";r.r(t),r.d(t,{Header:function(){return i}});var s=r(7573),n=r(3655),a=r(8487),c=r(8475);function i(){return(0,s.jsxs)("header",{className:"flex items-center justify-between border-b bg-white px-6 py-4",children:[(0,s.jsxs)("div",{className:"flex items-center space-x-4",children:[(0,s.jsxs)(n.qE,{className:"h-10 w-10",children:[(0,s.jsx)(n.F$,{src:"/avatar.png",alt:"User"}),(0,s.jsx)(n.Q5,{children:"U"})]}),(0,s.jsxs)("div",{children:[(0,s.jsx)("p",{className:"text-sm font-semibold",children:"Usu\xe1rio"}),(0,s.jsx)("p",{className:"text-xs text-muted-foreground",children:"usuario@email.com"})]})]}),(0,s.jsxs)("div",{className:"flex items-center space-x-4",children:[(0,s.jsx)("button",{className:"relative p-2 text-gray-600 hover:text-gray-900",children:(0,s.jsx)(a.Z,{className:"h-5 w-5"})}),(0,s.jsxs)("button",{className:"relative p-2 text-gray-600 hover:text-gray-900",children:[(0,s.jsx)(c.Z,{className:"h-5 w-5"}),(0,s.jsx)("span",{className:"absolute right-1 top-1 h-2 w-2 rounded-full bg-red-500"})]})]})]})}},5039:function(e,t,r){"use strict";r.r(t),r.d(t,{Sidebar:function(){return b}});var s=r(7573),n=r(8525);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,n.Z)("Home",[["path",{d:"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"y5dka4"}],["polyline",{points:"9 22 9 12 15 12 15 22",key:"e2us08"}]]);var c=r(7526);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,n.Z)("Radio",[["path",{d:"M4.9 19.1C1 15.2 1 8.8 4.9 4.9",key:"1vaf9d"}],["path",{d:"M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.5",key:"u1ii0m"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}],["path",{d:"M16.2 7.8c2.3 2.3 2.3 6.1 0 8.5",key:"1j5fej"}],["path",{d:"M19.1 4.9C23 8.8 23 15.1 19.1 19",key:"10b0cb"}]]);var l=r(3385),o=r(7542),u=r(4565),h=r(1236),d=r(5835),f=r(5104),y=r(7997),x=r(4603),m=r(3655);let p=[{icon:a,label:"Dashboard",href:"/"},{icon:c.Z,label:"Voos",href:"/flights"},{icon:i,label:"Voos ao Vivo",href:"/live-flights"},{icon:l.Z,label:"Reservas",href:"/bookings"},{icon:o.Z,label:"Passageiros",href:"/passengers"},{icon:u.Z,label:"Pagamentos",href:"/payments"},{icon:h.Z,label:"Relat\xf3rios",href:"/reports"},{icon:d.Z,label:"Configura\xe7\xf5es",href:"/settings"},{icon:f.Z,label:"Ajuda",href:"/help"}];function b(){let e=(0,x.usePathname)();return(0,s.jsxs)("div",{className:"flex h-full w-16 flex-col items-center bg-gray-900 py-4",children:[(0,s.jsx)("div",{className:"mb-8",children:(0,s.jsx)("div",{className:"h-10 w-10 rounded-full bg-primary flex items-center justify-center text-white font-bold",children:"V"})}),(0,s.jsx)("nav",{className:"flex flex-1 flex-col items-center space-y-4",children:p.map(t=>{let r=t.icon,n=e===t.href;return(0,s.jsx)(y.default,{href:t.href,className:(0,m.cn)("flex h-12 w-12 items-center justify-center rounded-lg transition-colors hover:bg-gray-800",n&&"bg-primary text-white"),title:t.label,children:(0,s.jsx)(r,{className:"h-5 w-5"})},t.href)})})]})}},4603:function(e,t,r){"use strict";var s=r(2988);r.o(s,"usePathname")&&r.d(t,{usePathname:function(){return s.usePathname}}),r.o(s,"useRouter")&&r.d(t,{useRouter:function(){return s.useRouter}})}},function(e){e.O(0,[480,802,548,293,997,744],function(){return e(e.s=4040)}),_N_E=e.O()}]);