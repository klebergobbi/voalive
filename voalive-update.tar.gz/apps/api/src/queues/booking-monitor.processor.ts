/**
 * Booking Monitor Processor
 * Worker que processa jobs de monitoramento de reservas
 */

import { Job, Worker } from 'bullmq';
import { getAirlineMonitoringService } from '../services/airline-monitoring.service';
import { Logger } from '../utils/logger.util';

const logger = new Logger('BookingMonitorProcessor');

export interface CheckBookingStatusJob {
  bookingId: string;
  pnr: string;
  lastName: string;
  airline: string;
}

/**
 * Processa job de verificação de status
 */
async function processCheckBookingStatus(job: Job<CheckBookingStatusJob>): Promise<void> {
  const { bookingId, pnr, airline } = job.data;

  logger.info(`Processando job ${job.id}: verificar status de ${pnr} (${airline})`);

  try {
    const monitoringService = getAirlineMonitoringService();
    await monitoringService.checkBookingStatus(bookingId);

    logger.info(`Job ${job.id} processado com sucesso`);
  } catch (error: any) {
    logger.error(`Erro ao processar job ${job.id}:`, error.message);
    throw error; // Re-throw para BullMQ fazer retry
  }
}

/**
 * Cria e inicia o worker
 */
export function createBookingMonitorWorker(connection: any): Worker {
  logger.info('Criando worker de monitoramento de reservas...');

  const worker = new Worker(
    'booking-monitor',
    async (job: Job) => {
      logger.info(`Worker recebeu job ${job.id}: ${job.name}`);

      switch (job.name) {
        case 'check-booking-status':
          await processCheckBookingStatus(job);
          break;

        default:
          logger.warn(`Tipo de job desconhecido: ${job.name}`);
      }
    },
    {
      connection,
      concurrency: 5, // Processar até 5 jobs simultaneamente
      limiter: {
        max: 10, // Máximo de 10 jobs
        duration: 60000, // Por minuto
      },
    }
  );

  // Event listeners
  worker.on('completed', (job) => {
    logger.info(`Job ${job.id} concluído com sucesso`);
  });

  worker.on('failed', (job, error) => {
    if (job) {
      logger.error(`Job ${job.id} falhou:`, error.message);
    } else {
      logger.error('Job falhou:', error.message);
    }
  });

  worker.on('error', (error) => {
    logger.error('Erro no worker:', error.message);
  });

  logger.info('Worker de monitoramento criado e iniciado');

  return worker;
}
