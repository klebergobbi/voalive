'use client';

import { useState } from 'react';
import { Search, Plane, Calendar, User, LogOut, Bell } from 'lucide-react';
import { AuthGuard } from '../../components/auth/AuthGuard';
import { BookingRegisterModal } from '../../components/dashboard/booking-register-modal';

export default function DashboardPage() {
  return (
    <AuthGuard>
      <DashboardContent />
    </AuthGuard>
  );
}

function DashboardContent() {
  const [showBookingRegisterModal, setShowBookingRegisterModal] = useState(false);
  const [showSearchModal, setShowSearchModal] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/login';
  };

  return (
    <>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-cyan-50">
        {/* Header Minimalista */}
        <div className="bg-white shadow-sm border-b">
          <div className="container mx-auto px-6 py-4">
            <div className="flex items-center justify-between">
              {/* Logo */}
              <div className="flex items-center gap-3">
                <div className="relative w-12 h-12 bg-gradient-to-br from-blue-900 via-blue-800 to-cyan-500 rounded-xl flex items-center justify-center shadow-md">
                  <Plane className="w-6 h-6 text-white transform rotate-45" strokeWidth={2.5} />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-blue-900">Reserva Segura</h1>
                  <p className="text-xs text-cyan-600 font-medium uppercase tracking-wide">Dashboard</p>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-3">
                <button
                  onClick={() => window.location.href = '/profile'}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                  title="Perfil"
                >
                  <User className="w-5 h-5 text-gray-600" />
                </button>
                <button
                  onClick={handleLogout}
                  className="flex items-center gap-2 px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  <span className="hidden sm:inline">Sair</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content - 3 Cards Principais */}
        <div className="container mx-auto px-6 py-16">
          {/* Título e Subtítulo */}
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-blue-900 mb-3">Simples e Rápido</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Busque, compre, reserve e viaje. Tudo isso em apenas 3 cliques.
              <br />
              Todo conforto e seu controle de suas viagens na palma da mão.
            </p>
          </div>

          {/* 3 Cards de Ação */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Card 1: Buscar */}
            <button
              onClick={() => setShowSearchModal(true)}
              className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 p-8 flex flex-col items-center text-center hover:scale-105 border-2 border-transparent hover:border-cyan-400"
            >
              <div className="w-24 h-24 bg-gradient-to-br from-cyan-400 to-cyan-600 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg">
                <Search className="w-12 h-12 text-white" strokeWidth={2} />
              </div>
              <h3 className="text-2xl font-bold text-blue-900 mb-2">1. Buscar</h3>
              <p className="text-gray-600">
                Pesquise seus voos e reservas cadastradas no sistema
              </p>
            </button>

            {/* Card 2: Reservar */}
            <button
              onClick={() => setShowBookingRegisterModal(true)}
              className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 p-8 flex flex-col items-center text-center hover:scale-105 border-2 border-transparent hover:border-blue-400"
            >
              <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg">
                <Calendar className="w-12 h-12 text-white" strokeWidth={2} />
              </div>
              <h3 className="text-2xl font-bold text-blue-900 mb-2">2. Reservar</h3>
              <p className="text-gray-600">
                Cadastre uma nova reserva para monitoramento automático
              </p>
            </button>

            {/* Card 3: Viagem */}
            <button
              onClick={() => window.location.href = '/flights'}
              className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 p-8 flex flex-col items-center text-center hover:scale-105 border-2 border-transparent hover:border-purple-400"
            >
              <div className="w-24 h-24 bg-gradient-to-br from-purple-500 to-purple-700 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg">
                <Plane className="w-12 h-12 text-white" strokeWidth={2} />
              </div>
              <h3 className="text-2xl font-bold text-blue-900 mb-2">3. Viagem</h3>
              <p className="text-gray-600">
                Gerencie todas as suas viagens e acompanhe o status
              </p>
            </button>
          </div>

          {/* Seção de Recursos */}
          <div className="mt-16 bg-white rounded-2xl shadow-lg p-8 max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold text-blue-900 mb-6 text-center">
              Reserve com Segurança
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h4 className="font-semibold text-blue-900 mb-2">Pagamento Seguro</h4>
                <p className="text-sm text-gray-600">Via pagamentos 3x17, garantia de 3 a 7 semanas de reembolso</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                </div>
                <h4 className="font-semibold text-blue-900 mb-2">Seguro 24/7</h4>
                <p className="text-sm text-gray-600">Sua tranquilidade é nossa prioridade</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Bell className="w-8 h-8 text-white" />
                </div>
                <h4 className="font-semibold text-blue-900 mb-2">Acompanhamento</h4>
                <p className="text-sm text-gray-600">Monitoramento automático de alterações</p>
              </div>
            </div>
          </div>

          {/* Badges de Companhias */}
          <div className="mt-12 flex items-center justify-center gap-8 flex-wrap opacity-60">
            <div className="text-center">
              <div className="text-sm font-semibold text-blue-900">Parceiros</div>
            </div>
            <div className="px-4 py-2 bg-white rounded-lg shadow">
              <span className="font-bold text-blue-700">GOL</span>
            </div>
            <div className="px-4 py-2 bg-white rounded-lg shadow">
              <span className="font-bold text-red-600">LATAM</span>
            </div>
            <div className="px-4 py-2 bg-white rounded-lg shadow">
              <span className="font-bold text-blue-600">AZUL</span>
            </div>
          </div>
        </div>
      </div>

      {/* Modal de Busca */}
      {showSearchModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full mx-4 overflow-hidden">
            <div className="bg-gradient-to-r from-cyan-500 to-cyan-600 p-6">
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-bold text-white">Buscar Voos e Reservas</h3>
                <button
                  onClick={() => setShowSearchModal(false)}
                  className="text-white hover:bg-white/20 rounded-lg p-2 transition-colors"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              {/* Busca por Localizador */}
              <div>
                <label className="block text-sm font-semibold text-blue-900 mb-2">
                  Localizador da Reserva
                </label>
                <input
                  type="text"
                  placeholder="Ex: ABC123"
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent text-lg"
                />
              </div>

              {/* Busca por Nome */}
              <div>
                <label className="block text-sm font-semibold text-blue-900 mb-2">
                  Nome do Passageiro
                </label>
                <input
                  type="text"
                  placeholder="Digite o nome completo"
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
                />
              </div>

              {/* Botões de Navegação Rápida */}
              <div className="grid grid-cols-2 gap-4 pt-4">
                <button
                  onClick={() => {
                    setShowSearchModal(false);
                    window.location.href = '/flights';
                  }}
                  className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold"
                >
                  Ver Todos os Voos
                </button>
                <button
                  onClick={() => {
                    setShowSearchModal(false);
                    window.location.href = '/bookings';
                  }}
                  className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-semibold"
                >
                  Ver Todas as Reservas
                </button>
              </div>

              <button
                onClick={() => setShowSearchModal(false)}
                className="w-full px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-semibold"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Cadastro de Reserva */}
      <BookingRegisterModal
        isOpen={showBookingRegisterModal}
        onClose={() => setShowBookingRegisterModal(false)}
        onSuccess={() => {
          setShowBookingRegisterModal(false);
          window.location.href = '/bookings';
        }}
      />
    </>
  );
}
