'use client';

import { useState } from 'react';
import { X, Search, Plane, Loader2 } from 'lucide-react';

interface BookingRegisterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export function BookingRegisterModal({ isOpen, onClose, onSuccess }: BookingRegisterModalProps) {
  const [flightNumber, setFlightNumber] = useState('');
  const [localizador, setLocalizador] = useState('');
  const [ultimoNome, setUltimoNome] = useState('');
  const [origem, setOrigem] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [flightInfo, setFlightInfo] = useState<any>(null);

  const isGol = (flightNum: string): boolean => {
    const code = flightNum.substring(0, 2).toUpperCase();
    return code === 'G3';
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!flightNumber.trim() || flightNumber.length < 4) {
      setError('Por favor, digite um número de vôo válido (mínimo 4 caracteres)');
      return;
    }

    // Validação específica para GOL
    if (isGol(flightNumber)) {
      if (!localizador.trim()) {
        setError('Para voos GOL, o Localizador é obrigatório');
        return;
      }
      if (!ultimoNome.trim()) {
        setError('Para voos GOL, o Último Nome é obrigatório');
        return;
      }
      if (!origem.trim()) {
        setError('Para voos GOL, a Origem é obrigatória');
        return;
      }
    }

    setLoading(true);
    setError('');
    setFlightInfo(null);

    try {
      console.log('🔍 Buscando vôo real:', flightNumber);

      const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';
      const searchData: any = {
        flightNumber: flightNumber.trim().toUpperCase()
      };

      // Adiciona campos extras se preenchidos
      if (localizador.trim()) searchData.localizador = localizador.trim().toUpperCase();
      if (ultimoNome.trim()) searchData.ultimoNome = ultimoNome.trim().toUpperCase();
      if (origem.trim()) searchData.origem = origem.trim().toUpperCase();

      const response = await fetch(`${apiUrl}/api/v1/flight-search/search`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(searchData),
      });

      const result = await response.json();

      if (result.success && result.data) {
        console.log('✅ Vôo encontrado:', result.data);
        setFlightInfo(result.data);

        // Close modal after 2 seconds and redirect to flights page
        setTimeout(() => {
          onSuccess?.();
        }, 2000);
      } else {
        setError(result.error || 'Vôo não encontrado. Verifique o número e tente novamente.');
        console.warn('⚠️ Vôo não encontrado:', result);
      }
    } catch (error: any) {
      console.error('❌ Erro na busca:', error);
      setError(`Erro ao buscar vôo: ${error.message || 'Verifique sua conexão'}`);
    } finally {
      setLoading(false);
    }
  };

  const formatFlightNumber = (value: string) => {
    return value.toUpperCase().replace(/\s/g, '');
  };

  const handleFlightNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatFlightNumber(e.target.value);
    setFlightNumber(formatted);
    setError('');
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl shadow-2xl max-w-md w-full mx-4"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-green-500 to-green-600 p-6 rounded-t-2xl">
          <div className="flex items-center justify-between">
            <h3 className="text-2xl font-bold text-white flex items-center gap-2">
              <Plane className="h-6 w-6" />
              Buscar Vôo
            </h3>
            <button
              onClick={onClose}
              className="text-white hover:bg-white/20 rounded-lg p-2 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Form Content */}
        <form onSubmit={handleSearch} className="p-6 space-y-4">
          {/* Número do Vôo */}
          <div className="space-y-2">
            <label className="block text-sm font-semibold text-blue-900">
              Número do Vôo {isGol(flightNumber) && <span className="text-red-600">*</span>}
            </label>
            <div className="relative">
              <input
                type="text"
                value={flightNumber}
                onChange={handleFlightNumberChange}
                placeholder="Ex: LA3789, G31234"
                required
                minLength={4}
                maxLength={8}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent font-mono text-lg"
                disabled={loading}
                autoFocus
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2">
                {loading ? (
                  <Loader2 className="h-5 w-5 animate-spin text-green-600" />
                ) : (
                  <Search className="h-5 w-5 text-gray-400" />
                )}
              </div>
            </div>
          </div>

          {/* Campos adicionais */}
          <div className="space-y-3">
            {/* Localizador */}
            <div className="space-y-2">
              <label className="block text-sm font-semibold text-blue-900">
                Localizador {isGol(flightNumber) && <span className="text-red-600">*</span>}
              </label>
              <input
                type="text"
                value={localizador}
                onChange={(e) => {
                  setLocalizador(e.target.value.toUpperCase());
                  setError('');
                }}
                placeholder="Ex: ABC123"
                maxLength={6}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent font-mono"
                disabled={loading}
                required={isGol(flightNumber)}
              />
            </div>

            {/* Último Nome */}
            <div className="space-y-2">
              <label className="block text-sm font-semibold text-blue-900">
                Último Nome {isGol(flightNumber) && <span className="text-red-600">*</span>}
              </label>
              <input
                type="text"
                value={ultimoNome}
                onChange={(e) => {
                  setUltimoNome(e.target.value.toUpperCase());
                  setError('');
                }}
                placeholder="Ex: SILVA"
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent font-mono"
                disabled={loading}
                required={isGol(flightNumber)}
              />
            </div>

            {/* Origem */}
            <div className="space-y-2">
              <label className="block text-sm font-semibold text-blue-900">
                Origem (IATA) {isGol(flightNumber) && <span className="text-red-600">*</span>}
              </label>
              <input
                type="text"
                value={origem}
                onChange={(e) => {
                  setOrigem(e.target.value.toUpperCase());
                  setError('');
                }}
                placeholder="Ex: GRU, CGH, SDU"
                maxLength={3}
                minLength={3}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent font-mono"
                disabled={loading}
                required={isGol(flightNumber)}
              />
            </div>
          </div>

          {/* Alerta para voos GOL */}
          {isGol(flightNumber) && (
            <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-sm text-yellow-800">
                <strong>Voos GOL:</strong> É necessário informar o Localizador, Último Nome e Origem para realizar a busca.
              </p>
            </div>
          )}

          {/* Success State */}
          {flightInfo && !error && (
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg space-y-3">
              <div className="flex items-center gap-2 text-green-700 font-medium">
                <span className="text-xl">✅</span>
                <span>Vôo Encontrado! Redirecionando...</span>
              </div>

              <div className="text-sm space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-green-700 font-medium">Vôo:</span>
                  <span className="font-mono font-bold text-green-900">{flightInfo.numeroVoo}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-green-700 font-medium">Companhia:</span>
                  <span className="font-medium text-green-900">{flightInfo.companhia || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-green-700 font-medium">Rota:</span>
                  <span className="font-medium text-green-900">{flightInfo.origem} → {flightInfo.destino}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-green-700 font-medium">Status:</span>
                  <span className={`font-semibold px-2 py-0.5 rounded text-xs ${
                    flightInfo.status?.includes('EM VOO') ? 'bg-blue-100 text-blue-800' :
                    flightInfo.status?.includes('ATRASADO') || flightInfo.atrasado ? 'bg-yellow-100 text-yellow-800' :
                    flightInfo.status?.includes('CANCELADO') ? 'bg-red-100 text-red-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {flightInfo.status}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Error State */}
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end gap-2 pt-4 border-t">
            <button
              type="button"
              onClick={() => {
                onClose();
                setFlightNumber('');
                setLocalizador('');
                setUltimoNome('');
                setOrigem('');
                setError('');
                setFlightInfo(null);
              }}
              disabled={loading}
              className="px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-semibold"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={flightNumber.length < 4 || loading}
              className="px-6 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-semibold min-w-32"
            >
              {loading ? (
                <div className="flex items-center gap-2 justify-center">
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Buscando...
                </div>
              ) : (
                <div className="flex items-center gap-2 justify-center">
                  <Search className="h-5 w-5" />
                  Buscar
                </div>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
